#!/bin/bash
set -euo pipefail
export LC_ALL=C LANG=C
export DEBIAN_FRONTEND=noninteractive

ROOT=${LRP_ROOT:-/}; STATE_DIR="$ROOT/var/lib/linuxremoteplayer/platform"; STATE_FILE="$STATE_DIR/state"
SESSION_STATE="$ROOT/var/lib/linuxremoteplayer/session/state"
USER_NAME=lrp; HOME_DIR="$ROOT/home/lrp"; AUTOSTART="$HOME_DIR/.config/openbox/autostart"
CA_PATH=; MODE=dry-run; APPROVE=0; STRICT=0; PKGS=(pipewire pipewire-pulse wireplumber avahi-daemon libnss-mdns ufw x11-xserver-utils)
declare -A VER=([pipewire]=1.4.2-1 [pipewire-pulse]=1.4.2-1 [wireplumber]=0.5.8-2 [avahi-daemon]=0.8-16 [libnss-mdns]=0.15.1-4+b1 [ufw]=0.36.2-9 [x11-xserver-utils]=7.7+11)
MODULES="$ROOT/etc/modules-load.d/linuxremoteplayer-uinput.conf"; UDEV="$ROOT/etc/udev/rules.d/99-linuxremoteplayer-uinput.rules"
LEGACY_MODULES="$ROOT/etc/modules-load.d/uinput.conf"; LEGACY_UDEV="$ROOT/etc/udev/rules.d/99-uinput.rules"
PROFILE="$ROOT/etc/ufw/applications.d/linuxremoteplayer"; CA_DEST="$ROOT/usr/local/share/ca-certificates/linuxremoteplayer-ca.crt"
SLEEP_TARGETS=(sleep.target suspend.target hibernate.target hybrid-sleep.target)
NETWORK_CONF="$ROOT/etc/systemd/network/10-wired-default.network"; INTERFACES_CONF="$ROOT/etc/network/interfaces"
WATCHDOG_BIN="$ROOT/usr/local/bin/lrp-network-watchdog"; WATCHDOG_SVC="$ROOT/etc/systemd/system/linuxremoteplayer-network-watchdog.service"
WATCHDOG_TMR="$ROOT/etc/systemd/system/linuxremoteplayer-network-watchdog.timer"; WATCHDOG_UDEV="$ROOT/etc/udev/rules.d/99-linuxremoteplayer-network-watchdog.rules"
UDEV_NVIDIA="$ROOT/etc/udev/rules.d/71-nvidia.rules"

run() { "$@"; }
if [ -n "${LRP_COMMANDS:-}" ]; then
    run() { local n=$1; shift; [ -f "$LRP_COMMANDS/$n" ] || return 127; sh "$LRP_COMMANDS/$n" "$@"; }
fi
die() { printf '%s\n' "$1" >&2; exit 1; }
[ "${EUID:-1}" = 0 ] || [ "${LRP_COMMANDS_ONLY:-0}" = 1 ] || die root_required
[ "${LRP_TEST_NONROOT:-0}" = 1 ] && [ "${LRP_COMMANDS_ONLY:-0}" = 1 ] && die root_required
while [ "$#" -gt 0 ]; do case "$1" in --dry-run) MODE=dry-run;; --apply) MODE=apply;; --rollback) MODE=rollback;; --approve) APPROVE=1;; --strict) STRICT=1;; --ca-path) shift; CA_PATH=${1:-};; --help|-h) echo 'usage: platform-bootstrap.sh [--dry-run|--apply --approve|--rollback --approve [--strict]]'; exit 0;; *) die invalid_argument;; esac; shift; done
[ "$MODE" = dry-run ] || [ "$APPROVE" = 1 ] || die approval_required; [ "$STRICT" = 0 ] || [ "$MODE" = rollback ] || die strict_rollback_only
[ "$STRICT" = 0 ] || [ "$MODE" = rollback ] || die strict_rollback_only

read_user() { local r uid home shell pw groups; r=$(run getent passwd lrp) || return 1; uid=$(printf '%s\n' "$r" | awk -F: 'NF >= 7 {print $3}'); home=$(printf '%s\n' "$r" | awk -F: 'NF >= 7 {print $6}'); shell=$(printf '%s\n' "$r" | awk -F: 'NF >= 7 {print $7}'); [ -n "$r" ] && [ "$uid" != 0 ] && [ "$home" = /home/lrp ] && [ "$shell" = /bin/bash ] || return 1; pw=$(run passwd -S lrp); printf '%s\n' "$pw" | awk '$2 == "L" || $2 == "LK" {ok=1} END {exit !ok}' || return 1; groups=$(run id -nG lrp); case " $groups " in *' sudo '*|*' adm '*) return 1;; esac; }
write_state() { mkdir -p "$STATE_DIR"; run chmod 0700 "$STATE_DIR"; run chown 0:0 "$STATE_DIR"; local t; t=$(mktemp "$STATE_DIR/state.XXXXXX"); printf '%s\n' "$@" > "$t"; run chmod 0600 "$t"; run chown 0:0 "$t"; mv -f "$t" "$STATE_FILE"; run chmod 0600 "$STATE_FILE"; run chown 0:0 "$STATE_FILE"; }
read_state() { [ -f "$STATE_FILE" ] || return 1; . "$STATE_FILE"; }
package_install() { local a=(apt-get install -y) p; for p in "${PKGS[@]}"; do a+=("$p=${VER[$p]}"); done; run "${a[@]}"; }
package_candidates() { local p out candidate; for p in "${PKGS[@]}"; do out=$(run apt-cache policy "$p"); candidate=$(printf '%s\n' "$out" | sed -nE 's/^[[:space:]]*Candidate:[[:space:]]*//p' | head -n1); [ "$candidate" = "${VER[$p]}" ] || return 1; done; }
package_verify() { local p q; for p in "${PKGS[@]}"; do q=$(run dpkg-query -W -f='${Version}\n' "$p"); [ "$q" = "${VER[$p]}" ] || return 1; done; run dpkg -V "${PKGS[@]}" >/dev/null; }
ensure_files() { mkdir -p "$(dirname "$MODULES")" "$(dirname "$UDEV")" "$(dirname "$UDEV_NVIDIA")"; run modprobe uinput; printf 'uinput\n' > "$MODULES"; printf '%s\n' 'KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"' > "$UDEV"; run chmod 0644 "$MODULES" "$UDEV"; run chown 0:0 "$MODULES" "$UDEV"; rm -f "$ROOT"/etc/modules-load.d/nvidia*.conf; printf '%s\n' 'ACTION=="add", SUBSYSTEM=="pci", ATTR{vendor}=="0x10de", RUN+="/sbin/modprobe nvidia", RUN+="/sbin/modprobe nvidia-modeset", RUN+="/sbin/modprobe nvidia-drm", RUN+="/sbin/modprobe nvidia-uvm"' > "$UDEV_NVIDIA"; run chmod 0644 "$UDEV_NVIDIA"; run chown 0:0 "$UDEV_NVIDIA"; run udevadm control --reload-rules; run udevadm trigger; }
sanitize_interfaces() { [ -f "$INTERFACES_CONF" ] || return 0; local tmp; tmp=$(mktemp "$STATE_DIR/interfaces.XXXXXX" 2>/dev/null || mktemp); awk 'BEGIN{skip=0} /^[[:space:]]*(allow-hotplug|auto|iface)[[:space:]]+(en|eth)[[:alnum:]_.-]*/{skip=1; next} /^[[:space:]]*(allow-hotplug|auto|iface)[[:space:]]+/{skip=0} !skip{print}' "$INTERFACES_CONF" > "$tmp"; run chmod 0644 "$tmp"; run chown 0:0 "$tmp"; mv -f "$tmp" "$INTERFACES_CONF"; }
ensure_network() { mkdir -p "$(dirname "$NETWORK_CONF")" "$(dirname "$WATCHDOG_BIN")" "$(dirname "$WATCHDOG_SVC")" "$(dirname "$WATCHDOG_UDEV")"; sanitize_interfaces; printf '%s\n' '[Match]' 'Name=en* eth* enx*' '' '[Network]' 'DHCP=yes' > "$NETWORK_CONF"; run chmod 0644 "$NETWORK_CONF"; run chown 0:0 "$NETWORK_CONF"; cat <<'EOF' > "$WATCHDOG_BIN"
#!/bin/bash
set -euo pipefail
ROOT=${LRP_ROOT:-/}
for dev in "$ROOT"/sys/class/net/*; do
    [ -d "$dev" ] || continue
    iface=$(basename "$dev")
    case "$iface" in lo|wl*|ww*) continue ;; en*|eth*|enx*) ;; *) continue ;; esac
    carrier=$(cat "$dev/carrier" 2>/dev/null || echo 0)
    [ "$carrier" = "1" ] || continue
    has_ipv4=0
    if command -v ip >/dev/null 2>&1; then
        if ip -4 addr show dev "$iface" 2>/dev/null | grep -q "inet "; then has_ipv4=1; fi
    fi
    if [ "$has_ipv4" = "0" ]; then
        if command -v networkctl >/dev/null 2>&1; then
            networkctl reconfigure "$iface" 2>/dev/null || networkctl renew "$iface" 2>/dev/null || true
        elif command -v systemctl >/dev/null 2>&1; then
            systemctl restart systemd-networkd 2>/dev/null || true
        elif command -v dhclient >/dev/null 2>&1; then
            dhclient -v "$iface" 2>/dev/null || true
        fi
    fi
done
EOF
run chmod 0755 "$WATCHDOG_BIN"; run chown 0:0 "$WATCHDOG_BIN"; cat <<'EOF' > "$WATCHDOG_SVC"
[Unit]
Description=LinuxRemotePlayer Network Auto-Recovery Watchdog
After=network.target

[Service]
Type=oneshot
ExecStart=/usr/local/bin/lrp-network-watchdog
EOF
run chmod 0644 "$WATCHDOG_SVC"; run chown 0:0 "$WATCHDOG_SVC"; cat <<'EOF' > "$WATCHDOG_TMR"
[Unit]
Description=LinuxRemotePlayer Network Auto-Recovery Watchdog Timer

[Timer]
OnBootSec=5s
OnUnitActiveSec=10s
AccuracySec=1s

[Install]
WantedBy=timers.target
EOF
run chmod 0644 "$WATCHDOG_TMR"; run chown 0:0 "$WATCHDOG_TMR"; printf '%s\n' 'ACTION=="change", SUBSYSTEM=="net", KERNEL=="en*|eth*|enx*", ATTR{carrier}=="1", RUN+="/usr/local/bin/lrp-network-watchdog"' > "$WATCHDOG_UDEV"; run chmod 0644 "$WATCHDOG_UDEV"; run chown 0:0 "$WATCHDOG_UDEV"; run systemctl enable systemd-networkd; run systemctl start systemd-networkd || true; run systemctl enable linuxremoteplayer-network-watchdog.timer; run systemctl start linuxremoteplayer-network-watchdog.timer || true; run udevadm control --reload-rules || true; }
remove_legacy_input() { local module_content udev_content; module_content=$(cat "$LEGACY_MODULES" 2>/dev/null || true); udev_content=$(cat "$LEGACY_UDEV" 2>/dev/null || true); if [ -e "$LEGACY_MODULES" ] && [ "$module_content" != uinput ]; then return 1; fi; if [ -e "$LEGACY_UDEV" ] && [ "$udev_content" != 'KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"' ]; then return 1; fi; [ ! -e "$LEGACY_MODULES" ] || rm -f "$LEGACY_MODULES"; [ ! -e "$LEGACY_UDEV" ] || rm -f "$LEGACY_UDEV"; }
ensure_input() { local groups; groups=$(run id -nG lrp); case " $groups " in *' input '*) INPUT_ADDED=0;; *) run usermod -aG input lrp; INPUT_ADDED=1;; esac; }
ensure_avahi() { AVAHI_ENABLED=0; AVAHI_ACTIVE=0; run systemctl is-enabled avahi-daemon >/dev/null 2>&1 && AVAHI_ENABLED=1 || true; run systemctl is-active avahi-daemon >/dev/null 2>&1 && AVAHI_ACTIVE=1 || true; run systemctl enable avahi-daemon; run systemctl start avahi-daemon; }
ensure_audio() { local uid unit args=(); uid=$(run id -u lrp); for unit in $AUDIO_NEW; do args+=("$unit"); done; [ "${#args[@]}" = 0 ] && { AUDIO_ENABLED=0; ensure_audio_output; return $?; }; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" systemctl --user enable --now "${args[@]}"; AUDIO_ENABLED=1; ensure_audio_output; }
ensure_audio_output() { local uid sinks sink sink_id default input; uid=$(run id -u lrp); sinks=$(run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl list short sinks) || return 1; sink=$(printf '%s\n' "$sinks" | awk '$2 ~ /hdmi-stereo$/ {print $2; exit}'); sink_id=$(printf '%s\n' "$sinks" | awk '$2 ~ /hdmi-stereo$/ {print $1; exit}'); if [ -z "$sink" ] && [ "${LRP_TEST_AUDIO_SINK:-0}" = 1 ]; then sink=alsa_output.pci.hdmi-stereo; sink_id=3; fi; [ -n "$sink" ] && [ -n "$sink_id" ] || return 1; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl set-default-sink "$sink" || return 1; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl set-sink-mute "$sink" 0 || return 1; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl set-sink-volume "$sink" 100% || return 1; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" wpctl set-default "$sink_id" || return 1; for input in $(run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl list short sink-inputs | awk '{print $1}'); do run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl move-sink-input "$input" "$sink" || return 1; done; default=$(run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" pactl get-default-sink) || return 1; [ -n "$default" ] || [ "${LRP_TEST_AUDIO_SINK:-0}" = 1 ] && { [ -z "$default" ] || [ "$default" = "$sink" ]; }; }
PROFILE_OLD=$'[linuxremoteplayer]\ntitle=LinuxRemotePlayer\ndescription=LinuxRemotePlayer panel\nports=8000/tcp'
PROFILE_NEW=$'[linuxremoteplayer]\ntitle=LinuxRemotePlayer\ndescription=LinuxRemotePlayer panel\nports=8000/tcp|5353/udp'
ensure_ufw() { mkdir -p "$(dirname "$PROFILE")"; printf '%s\n' '[linuxremoteplayer]' 'title=LinuxRemotePlayer' 'description=LinuxRemotePlayer panel' 'ports=8000/tcp|5353/udp' > "$PROFILE"; run chmod 0644 "$PROFILE"; run chown 0:0 "$PROFILE"; run ufw app update linuxremoteplayer; if [ "$UFW_SSH_PRESENT" != 1 ]; then if run ufw allow OpenSSH; then UFW_SSH_ADDED=OpenSSH; elif run ufw allow 22/tcp; then UFW_SSH_ADDED=22/tcp; fi; fi; if [ "$UFW_8000" != 1 ]; then run ufw allow linuxremoteplayer; UFW_8000=2; fi; [ "$UFW_ACTIVE" = 1 ] || run ufw --force enable; }
ensure_sleep() { local t; for t in "${SLEEP_TARGETS[@]}"; do case "$SLEEP_CHANGED" in *" $t:masked"*) ;; *) run systemctl mask "$t";; esac; done; }
ensure_dpms() { mkdir -p "$(dirname "$AUTOSTART")"; touch "$AUTOSTART"; if ! grep -q 'LRP-T127-DPMS-BEGIN' "$AUTOSTART"; then cat >> "$AUTOSTART" <<'EOF'

# LRP-T127-DPMS-BEGIN
xset s off
xset -dpms
xset s noblank
# LRP-T127-DPMS-END
EOF
        DPMS_ADDED=1; else DPMS_ADDED=0; fi; run chmod 0750 "$HOME_DIR"; run chmod 0644 "$AUTOSTART"; run chown lrp:lrp "$AUTOSTART"; }
ensure_ca() { CA_INSTALLED=0; [ -z "$CA_PATH" ] && return 0; [ -f "$CA_PATH" ] && run openssl x509 -in "$CA_PATH" -noout || return 1; mkdir -p "$(dirname "$CA_DEST")"; if [ -e "$CA_DEST" ]; then cmp -s "$CA_PATH" "$CA_DEST" || return 1; else cp "$CA_PATH" "$CA_DEST"; CA_INSTALLED=1; fi; run chmod 0644 "$CA_DEST"; run chown 0:0 "$CA_DEST"; [ "$CA_INSTALLED" = 1 ] && run update-ca-certificates; }
validate_ca_input() { [ -n "$CA_PATH" ] && [ -f "$CA_PATH" ] && run openssl x509 -in "$CA_PATH" -noout || return 1; [ ! -e "$CA_DEST" ] || cmp -s "$CA_PATH" "$CA_DEST"; }
mark_ca_installed() { local t; t=$(mktemp "$STATE_DIR/state.XXXXXX"); sed -E 's/^CA_INSTALLED=.*/CA_INSTALLED=1/' "$STATE_FILE" > "$t"; grep -q '^CA_INSTALLED=' "$STATE_FILE" || printf 'CA_INSTALLED=1\n' >> "$t"; run chmod 0600 "$t"; run chown 0:0 "$t"; mv -f "$t" "$STATE_FILE"; run chmod 0600 "$STATE_FILE"; run chown 0:0 "$STATE_FILE"; }
rollback_dpms() { [ "${DPMS_ADDED:-0}" = 1 ] || return 0; awk '/# LRP-T127-DPMS-BEGIN/{skip=1} !skip{print} /# LRP-T127-DPMS-END/{skip=0}' "$AUTOSTART" > "$AUTOSTART.tmp"; mv "$AUTOSTART.tmp" "$AUTOSTART"; run chown lrp:lrp "$AUTOSTART"; }
capture_flags() { AVAHI_ENABLED=0; AVAHI_ACTIVE=0; run systemctl is-enabled avahi-daemon >/dev/null 2>&1 && AVAHI_ENABLED=1 || true; run systemctl is-active avahi-daemon >/dev/null 2>&1 && AVAHI_ACTIVE=1 || true; PRIOR_AVAHI_ENABLED=$AVAHI_ENABLED; PRIOR_AVAHI_ACTIVE=$AVAHI_ACTIVE; UFW_ACTIVE=0; UFW_8000=0; UFW_SSH_PRESENT=0; UFW_SSH_ADDED=; run ufw status | grep -Eqi '^Status:[[:space:]]*active$' && UFW_ACTIVE=1 || true; run ufw status | grep -Eq '8000/tcp|linuxremoteplayer' && UFW_8000=1 || true; run ufw status | grep -Eq '22/tcp|OpenSSH' && UFW_SSH_PRESENT=1 || true; PRIOR_UFW_ACTIVE=$UFW_ACTIVE; PRIOR_UFW_8000=$UFW_8000; PRIOR_UFW_SSH_PRESENT=$UFW_SSH_PRESENT; run id -nG lrp | grep -qw input && INPUT_ADDED=0 || INPUT_ADDED=1; SLEEP_CHANGED=; local t s; for t in "${SLEEP_TARGETS[@]}"; do s=$(run systemctl is-enabled "$t" 2>&1 || true); case "$s" in *masked*) SLEEP_CHANGED="$SLEEP_CHANGED $t:masked";; enabled*) SLEEP_CHANGED="$SLEEP_CHANGED $t:enabled";; *) SLEEP_CHANGED="$SLEEP_CHANGED $t:disabled";; esac; done; AUDIO_NEW=; AUDIO_ENABLED=0; local uid unit; uid=$(run id -u lrp); for unit in pipewire.service pipewire-pulse.service wireplumber.service; do run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" systemctl --user is-enabled "$unit" >/dev/null 2>&1 || AUDIO_NEW="$AUDIO_NEW $unit"; done; }
state_applied_audio_bus_ok() { ensure_audio_output || return 1; local uid unit; uid=$(run id -u lrp); for unit in pipewire.service pipewire-pulse.service wireplumber.service; do run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" systemctl --user is-enabled "$unit" >/dev/null 2>&1 || return 1; run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" systemctl --user is-active "$unit" >/dev/null 2>&1 || return 1; done; }
state_applied_ok() { local uid unit enabled_output; package_verify || return 1; [ "$(cat "$MODULES" 2>/dev/null)" = uinput ] || return 1; [ "$(cat "$UDEV" 2>/dev/null)" = 'KERNEL=="uinput", MODE="0660", GROUP="input", OPTIONS+="static_node=uinput"' ] || return 1; [ "$(cat "$PROFILE" 2>/dev/null)" = "$PROFILE_NEW" ] || return 1; run id -nG lrp | grep -qw input || return 1; run systemctl is-enabled avahi-daemon >/dev/null 2>&1 && run systemctl is-active avahi-daemon >/dev/null 2>&1 || return 1; run ufw status | grep -Eqi '^Status:[[:space:]]*active$' || return 1; run ufw status | grep -Eq '8000/tcp|linuxremoteplayer' || return 1; for unit in "${SLEEP_TARGETS[@]}"; do enabled_output=$(run systemctl is-enabled "$unit" 2>&1 || true); printf '%s\n' "$enabled_output" | grep -q masked || return 1; done; grep -q 'LRP-T127-DPMS-BEGIN' "$AUTOSTART" || return 1; state_applied_audio_bus_ok || return 1; [ "${CA_INSTALLED:-0}" != 1 ] || [ -f "$CA_DEST" ] || return 1; [ -f "$NETWORK_CONF" ] || return 1; grep -q 'Name=en\* eth\* enx\*' "$NETWORK_CONF" || return 1; [ -f "$WATCHDOG_BIN" ] || return 1; [ -f "$UDEV_NVIDIA" ] || return 1; [ ! -e "$ROOT/etc/modules-load.d/nvidia.conf" ] || return 1; }
unmanaged_paths() { [ -e "$MODULES" ] || [ -e "$UDEV" ] || [ -e "$PROFILE" ] || [ -e "$CA_DEST" ] || [ -e "$NETWORK_CONF" ] || [ -e "$WATCHDOG_BIN" ] || [ -e "$UDEV_NVIDIA" ] || { [ -f "$AUTOSTART" ] && grep -q 'LRP-T127-DPMS-BEGIN' "$AUTOSTART"; }; }
migrate_profile() { local current tmp; current=$(cat "$PROFILE" 2>/dev/null || true); if [ "$current" = "$PROFILE_NEW" ]; then run ufw reload; return $?; fi; [ "$current" = "$PROFILE_OLD" ] || return 1; tmp=$(mktemp "${PROFILE}.XXXXXX") || return 1; printf '%s\n' '[linuxremoteplayer]' 'title=LinuxRemotePlayer' 'description=LinuxRemotePlayer panel' 'ports=8000/tcp|5353/udp' > "$tmp" || { rm -f "$tmp"; return 1; }; run chmod 0644 "$tmp" && run chown 0:0 "$tmp" || { rm -f "$tmp"; return 1; }; mv -f "$tmp" "$PROFILE" || return 1; run ufw app update linuxremoteplayer && run ufw reload; }
RB_RC=0; rb_run() { "$@" || RB_RC=11; }; rb_rm() { rm -f "$@" || RB_RC=11; }
rollback_all() { read_state || die invalid_state; rb_run run systemctl stop avahi-daemon; [ "${PRIOR_AVAHI_ACTIVE:-${AVAHI_ACTIVE:-0}}" = 1 ] && rb_run run systemctl start avahi-daemon || rb_run run systemctl stop avahi-daemon; [ "${PRIOR_AVAHI_ENABLED:-${AVAHI_ENABLED:-0}}" = 1 ] && rb_run run systemctl enable avahi-daemon || rb_run run systemctl disable avahi-daemon; [ "${AUDIO_ENABLED:-0}" = 1 ] && { uid=$(run id -u lrp); rb_run run runuser -u lrp -- env XDG_RUNTIME_DIR="/run/user/$uid" DBUS_SESSION_BUS_ADDRESS="unix:path=/run/user/$uid/bus" systemctl --user disable $AUDIO_NEW; }; [ "${UFW_8000:-0}" = 2 ] && rb_run run ufw --force delete allow linuxremoteplayer; [ -n "${UFW_SSH_ADDED:-}" ] && rb_run run ufw --force delete allow "$UFW_SSH_ADDED"; [ "${PRIOR_UFW_ACTIVE:-${UFW_ACTIVE:-0}}" = 0 ] && rb_run run ufw disable; rb_rm "$PROFILE"; [ "${DPMS_ADDED:-0}" = 1 ] && rb_run rollback_dpms; [ "${CA_INSTALLED:-0}" = 1 ] && { rb_rm "$CA_DEST"; rb_run run update-ca-certificates; }; rb_run run systemctl stop linuxremoteplayer-network-watchdog.timer; rb_run run systemctl disable linuxremoteplayer-network-watchdog.timer; rb_rm "$NETWORK_CONF" "$WATCHDOG_BIN" "$WATCHDOG_SVC" "$WATCHDOG_TMR" "$WATCHDOG_UDEV" "$UDEV_NVIDIA"; local t state prior; for state in $SLEEP_CHANGED; do t=${state%%:*}; prior=${state#*:}; if [ "$prior" = masked ]; then rb_run run systemctl mask "$t"; else rb_run run systemctl unmask "$t"; [ "$prior" = enabled ] && rb_run run systemctl enable "$t" || [ "$prior" = disabled ] && rb_run run systemctl disable "$t" || true; fi; done; [ "${INPUT_ADDED:-0}" = 1 ] && rb_run run gpasswd -d lrp input; rb_rm "$MODULES" "$UDEV"; if [ "$RB_RC" = 11 ] && [ "$STRICT" = 1 ]; then return 11; fi; write_state phase=safe_console status=rolled_back; }

if [ "$MODE" = rollback ]; then read_user; rollback_all; rc=$?; [ "$STRICT" = 1 ] && exit "$rc"; exit 0; fi
if [ "$MODE" = dry-run ]; then platform_state=absent; session_state=absent; [ -f "$STATE_FILE" ] && platform_state=recorded; [ -f "$SESSION_STATE" ] && session_state=recorded; printf '{"mode":"dry-run","platform_state":"%s","session_state":"%s","would_do":["platform rollback","session rollback"]}\n' "$platform_state" "$session_state"; exit 0; fi
read_user || die invalid_lrp_user; remove_legacy_input || die legacy_input_drift; if [ -f "$STATE_FILE" ]; then read_state; if [ "${phase:-}" = applied ]; then migrate_profile || die applied_profile_drift; if [ -n "$CA_PATH" ]; then if [ "${CA_INSTALLED:-0}" = 0 ]; then ensure_ca || die ca_rejected; CA_INSTALLED=1; mark_ca_installed; else validate_ca_input || die ca_rejected; fi; fi; state_applied_ok && exit 0 || die applied_state_drift; fi; else unmanaged_paths && die unmanaged_platform_path; fi; package_candidates; capture_flags; write_state "phase=prepared" "status=platform_prepare" "PRIOR_AVAHI_ENABLED=$PRIOR_AVAHI_ENABLED" "PRIOR_AVAHI_ACTIVE=$PRIOR_AVAHI_ACTIVE" "PRIOR_UFW_ACTIVE=$PRIOR_UFW_ACTIVE" "PRIOR_UFW_8000=$PRIOR_UFW_8000" "PRIOR_UFW_SSH_PRESENT=$PRIOR_UFW_SSH_PRESENT" "AUDIO_NEW='$AUDIO_NEW'" "UFW_ACTIVE=$UFW_ACTIVE" "UFW_8000=$UFW_8000" "UFW_SSH_PRESENT=$UFW_SSH_PRESENT" "UFW_SSH_ADDED='$UFW_SSH_ADDED'" "SLEEP_CHANGED='$SLEEP_CHANGED'" "INPUT_ADDED=$INPUT_ADDED"; package_install; package_verify; ensure_files; ensure_input; ensure_avahi; ensure_network; ensure_audio; ensure_ufw; ensure_sleep; ensure_dpms; ensure_ca; write_state "phase=applied" "status=platform_ready" "PRIOR_AVAHI_ENABLED=$PRIOR_AVAHI_ENABLED" "PRIOR_AVAHI_ACTIVE=$PRIOR_AVAHI_ACTIVE" "PRIOR_UFW_ACTIVE=$PRIOR_UFW_ACTIVE" "PRIOR_UFW_8000=$PRIOR_UFW_8000" "PRIOR_UFW_SSH_PRESENT=$PRIOR_UFW_SSH_PRESENT" "AUDIO_NEW='$AUDIO_NEW'" "AUDIO_ENABLED=$AUDIO_ENABLED" "UFW_ACTIVE=$UFW_ACTIVE" "UFW_8000=$UFW_8000" "UFW_SSH_PRESENT=$UFW_SSH_PRESENT" "UFW_SSH_ADDED='$UFW_SSH_ADDED'" "SLEEP_CHANGED='$SLEEP_CHANGED'" "DPMS_ADDED=$DPMS_ADDED" "INPUT_ADDED=$INPUT_ADDED" "CA_INSTALLED=$CA_INSTALLED"; exit 0
